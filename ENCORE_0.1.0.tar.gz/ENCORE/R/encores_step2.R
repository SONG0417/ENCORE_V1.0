#' consensus clustering
#'
#' Using the expression matrix (Not required in sample mode) and the result from encore_step1 as input, encore_step2 will integrate distance information from low-entropy subspace and finish consensus clustering.
#
#' @param data matrix; Data matrix (each row is an cell, each column is a gene); when sample="TRUE", this parameter can be left unassigned.
#' @param result integer; default: NA. Must be set to the result from encore_step1.
#' @param ac vector; default: NA, in this way, 4 subspaces with lowest entropies will be used; User can select the informative subspaces according to t-sne plots resulted from encore_step1, eg: c=c(3,4), subspaces 3 and 4 will be used.
#' @param method character; default: spect. It can be set as spect(spectral clustering)/dbscan(hdbscan clustering)/both(automatically choose between speactral and hdbscan clusteringp; in this mode, k must be set to a clear prior value);
#' @param k vector; default: NA. k used in cell classification process. All of the k values in this vector will be evaluated, and the best one will be used for the final classification. In 'spect' mode, if this parameter not be set, the inferred k from encore_step1 will be used; in 'dbscan' mode, this parameter is not required; in 'both' mode, it is must be set to a prior value/values.
#' @param adjust character; default: TRUE; in default, if only one k in the k vector, k-1 and k+1 are also evaluated. if set to FALSE, only the k in k vector will be evaluated.
#' @param thread integer; default: 1; Number of threads used.
#' @param scale character; default: TRUE. Scale the data by log2 or log10.
#' @param sample character; default: FALSE; When deal with big data of tens of thousands of cells , this parameter can be set to TRUE and encore will sample "10000/sample_size" cells firstly, and extend the cluster results to other cells by an supervised method
#' @param minPts integer; default: 0; value of the minPts parameter in hdbscan cluster and in default set, 5, 10, 30 and 50 will be used for dataset with <250 cell, <5000 cells, <=10000 cells, >10000 cells.
#' @param perp integer; default: 0; Perplexity parameter in Rtsne function and in default, 15 and 30 will be used for dataset will <100 cells and >=100 cells.
#' @param pc numeric; default: 0.0001; The cut-off of adjusted p value of group markers.
#'
#' @examples
#' result1=encore_step1(data,method="kmeans",start=50)
#' result2=encore_step2(data=data,method="both",k=5,result=result1,thread=4)
#' result2=encore_step2(data=data,method="dbscan",result=result1,thread=4)
#'
#' @return List with the following elements
#' \item{cluster}{Vector, The final cell classification result}
#' \item{temp}{data.frame, Two-dimensional cell distribution obtained by tsne transformation}
#' \item{dist}{matrix, The learned distance matrix}
#' \item{best_k}{Integer, The best k for clustering in subspaces}
#' \item{best_c}{Vector, The best subspaces for cell classification}
#' \item{lss}{List,Intermediate results of spectral clustering; It will be outputted when sample="TRUE" and will be used in encore_large when run big dataset}
#'
#' @importFrom parallel makeCluster
#' @import parallel stopCluster
#' @import parallel clusterExport
#' @import parallel parLapply
#'
#' @export
encore_step2=function(data=NA,ac=NA,k=NA,adjust="TRUE",method="spect",result=NA,thread=4,sample="FALSE",scale="TRUE",minPts=0,perp=0,pc=0.0001){
       	#####define ac
	if(is.na(result)){
		stop("Please give the result of step1 to result")
	}
	if(sample=="TRUE" || sample=="T"){
		data=result$data
		result$data=NA
		scale="FALSE"
	}
	if(is.na(data)){
		stop("Please give the expression matrix to data")
	}
  if(scale=="TRUE"||scale=="T"){
    max_data=max(data)
    if(max_data>10000){
      data=log(data+1)/log(10)
    }else{
      data=log(data+1)/log(2)
    }
  }
	if(is.na(ac)){
                j=length(result$ac)
                if(j>4){
                        j=4
                }
                ac=result$ac[1:j]
        }
        ts=result$ts
        nac=c()
        for (i in 1:length(ac)){
                tt=ts[[ac[i]]]
                if(is.na(tt)){
                }else{
                        rm(tt)
                        nac=c(nac,i)
                }
        }
        ac=ac[nac]
        rm(nac)
        print("***The subspaces used in these step")
        print(ac)
	###define minpts and perp
        dim1=dim(data)[1]
        if(minPts==0){
                if(dim1<=250){
                        minPts=5
                }else if(dim1<=5000){
                        minPts=10
                }else if(dim1<=10000){
                        minPts=30
                }else{
                        minPts=50
                }
        }
        if(perp==0){
                if(dim1<=100){
                        perp=15
                }else{
                        perp=30
                }
        }
	###sample data to 1000*1000
        rname=row.names(data)
        data=as.data.frame(t(data))
        if(dim(data)[2]>1000){
                lindex=sort(sample(1:dim(data)[2],1000))
                data=data[,lindex]
        }else{
                lindex=1:dim(data)[2]
        }
        rindex=sort(sample(1:dim(data)[1],1000))
        data=data[rindex,]
	#######define cs
        nl=length(ac)
        cs=list()
        nuu=1
        for (i in 2:nl){
                cs[[nuu]]=ac[1:i]
                nuu=nuu+1
        }
        nc=length(cs)
	#######choose methods and k
	cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
	aucs=list()
	iaucs=c()
	nu=1
	if(method=="both"){
		if(is.na(k)){
			stopCluster(cl)
			stop("error, please give the prior k for spectral cluster firstly")
		}else{
			clusterExport(cl,"ts",envir = environment())
			clusterExport(cl,"minPts",envir = environment())
			pclusters=parLapply(cl,as.character(ac),part_cluster2)
			names(pclusters)=as.character(ac)
			rm(ts)
			dks=c()
			dnu=1
			for(i in as.character(cs[[1]])){
				dks[dnu]=max(pclusters[[i]])
				dnu=dnu+1
			}
			dscore=abs(mean(dks)-k)/min(c(k,dks))
			dscore2=abs(dks[1]-dks[2])
			num=1
			pclusterss=list()
			aucc=list()
			auccs=c()
			max=1
			if(dscore>=0.3 || dscore2>min(dks)){
				print("DBSCAN is not suitable in this case")
				corr=result$corr
				clusterExport(cl,"corr",envir = environment())
				lss=parLapply(cl,as.character(ac),LS)
				names(lss)=as.factor(as.character(ac))
				nac=c()
				rm(corr)
				for (i in 1:length(ac)){
        				tttt=lss[[i]]
        				if(tttt=="wrong"){
        				}else{
                				rm(tttt)
                				nac=c(nac,i)
        				}
				}
				ac=ac[nac]
				rm(nac)
				if(length(k)>1){
					ks=k
				}else if(adjust=="TRUE" || adjust=="T"){
					k=k[1]
					if(k>=3){
						ks=c(k-1,k,k+1)
					}else{
						ks=c(k,k+1,k+2)
					}
				}else{
					ks=c(k)
				}
				for(i in as.numeric(ks)){
					k=i
					clusterExport(cl,"k",envir = environment())
					clusterExport(cl,"lss",envir = environment())
					pclusterss[[num]]=parLapply(cl,as.character(ac),part_cluster1)
					names(pclusterss[[num]])=as.character(ac)
					num=num+1
				}
				rm(lss)
				stopCluster(cl)
				num=1
				for(i in as.numeric(ks)){
					dist=learn_distance(c=cs[[1]],pclusterss[[num]],result$diss,result$corr)
					aucc[[num]]=IAUC(data=data,index=lindex,dist=dist,c=c,pc=pc,perp=perp,minPts=minPts)
					rm(dist)
					auccs[num]=aucc[[num]]$IAUC
					if(length(k)==1 && i<k){
						auccs[num]=auccs[num]*0.95
					}
					num=num+1
				}
				for(i in 1:(num-1)){
					if(is.na(auccs[i])){
						auccs[i]=0
					}
				}
				print("***spectral cluster, k=")
				print(ks)
				print("***IAUC scores of ks=")
				print(auccs)
				max=order(auccs,decreasing=T)[1]
				pclusters=pclusterss[[max]]
				rm(pclusterss)
				k=ks[max]
				print(paste("***The best methods is spectral and k is",ks[max]))
			}else{
				stopCluster(cl)
				dist=learn_distance(c=cs[[1]],pclusters,result$diss,result$corr)
				aucc[[num]]=IAUC(data=data,index=lindex,dist=dist,c=c,pc=pc,perp=perp,minPts=minPts)
				max=1
				rm(dist)
				print("***the best method is dbscan")

			}
			aucs[[nu]]=aucc[[max]]
			iaucs[nu]=aucc[[max]]$IAUC
			rm(aucc)
		}
	}else if(method=="dbscan"){
		print("run cluster in subspace in DBSCAN mode")
		clusterExport(cl,"ts",envir = environment())
		clusterExport(cl,"minPts",envir = environment())
		pclusters=parLapply(cl,as.character(ac),part_cluster2)
		names(pclusters)=as.character(ac)
                rm(ts)
		stopCluster(cl)
		dist=learn_distance(c=cs[[1]],pclusters,result$diss,result$corr)
                aucs[[nu]]=IAUC(data=data,index=lindex,dist=dist,c=c,pc=pc,perp=perp,minPts=minPts)
		rm(dist)
                iaucs[nu]=aucs[[nu]]$IAUC
	}else if(method=="spect"){
		print("run cluster in subspace in spectral cluster mode")
               	corr=result$corr
                clusterExport(cl,"corr",envir = environment())
                lss=parLapply(cl,as.character(ac),LS)
                names(lss)=as.factor(as.character(ac))
                nac=c()
		            rm(corr)
                for (i in 1:length(ac)){
                	tttt=lss[[i]]
                        if(tttt=="wrong"){
                        }else{
                        	rm(tttt)
                            	nac=c(nac,i)
                      	}
            	}
                ac=ac[nac]
                rm(nac)
		if(is.na(k)){
			k=round(result$k,0)
		}
              	if(length(k)>1){
                       	ks=k
            	}else if(adjust=="TRUE" || adjust=="T"){
                      	k=k[1]
                       	if(k>=3){
                             	ks=c(k-1,k,k+1)
                      	}else{
                          	ks=c(k,k+1,k+2)
                       	}
           	}else{
                 	ks=c(k)
            	}
		num=1
		print("***Used ks in this study:")
		print(ks)
		pclusterss=list()
		aucc=list()
		auccs=c()
    for(i in as.numeric(ks)){
			 k=i
			 clusterExport(cl,"k",envir = environment())
		   clusterExport(cl,"lss",envir = environment())
			 ss=parLapply(cl,as.character(ac),part_cluster1)
			 pclusterss[[num]]=ss
			 names(pclusterss[[num]])=as.character(ac)
			 num=num+1
    }
		if(sample=="TRUE" || sample=="T"){
		}else{
			rm(lss)
		}
		stopCluster(cl)
		print("Start learn distance")
		num=1
		for(i in as.numeric(ks)){
			dist=learn_distance(c=cs[[1]],pclusterss[[num]],result$diss,result$corr)
			aucc[[num]]=IAUC(data=data,index=lindex,dist=dist,c=c,pc=pc,perp=perp,minPts=minPts)
        auccs[num]=aucc[[num]]$IAUC
			  rm(dist)
        num=num+1
   }
              	for(i in 1:(num-1)){
                	if(is.na(auccs[i])){
                        	auccs[i]=0
                      	}
             	}
            	print("***spectral cluster, k=")
            	print(ks)
               	print("***IAUC scores of ks=")
              	print(auccs)
                max=order(auccs,decreasing=T)[1]
              	pclusters=pclusterss[[max]]
             	rm(pclusterss)
		k=ks[max]
              	print(paste("***The best methods is spectral and k is",ks[max]))
		aucs[[nu]]=aucc[[max]]
		iaucs[nu]=aucc[[max]]$IAUC
		rm(aucc)
	}
	nu=nu+1
	nc=length(cs)
	print("Choose best subspaces")
	print(cs[[1]])
	if(nc>2){
		for(i in 2:nc){
			c=cs[[i]]
			print(c)
			dist=learn_distance(c,pclusters,result$diss,result$corr)
			auc=IAUC(data=data,index=lindex,dist=dist,c=c,pc=pc,perp=perp,minPts=minPts)
			rm(dist)
			aucs[[nu]]=auc
			iaucs[nu]=auc$IAUC
			nu=nu+1
		}
		rm(data)
		mauc=max(iaucs)
		print(paste("The largest IAUC is:",mauc))
		gmarkers=list()
		factor=c()
		for(i in 1:nc){
			if(is.null(aucs[[i]]$gene_markers)){
                                gmarkers[[i]]="no markers"
                                factor[i]=0
                        }else{
                        	gmarkers[[i]]=aucs[[i]]$gene_markers
			}
                }
		for(i in 1:nc){
                	g=gmarkers[[i]][gmarkers[[i]]$auc1>=mauc,]
                	factor[i]=length(g[,3])/max(as.numeric(as.character(aucs[[i]]$cluster)))
        	}
		score=c()
		mscore=0
		maxfactor=0
		max=1
		lf=median(factor[factor>0])
		mf=max(factor)
		print("The IAUC score: && the factors:")
		for(i in 1:(nu-1)){
        		if(is.na(iaucs[i])){
                		iaucs[i]=0
        		}
		  print(paste(iaucs[i],factor[i]))
			if(factor[i]>lf){
				score[i]=iaucs[i]+0.1*(factor[i]-lf)/(mf-lf)
			}else{
				score[i]=iaucs[i]
			}
        		if(score[i]>mscore){
                		max=i
               			mscore=score[i]
				maxfactor=factor[i]
        		}else if(score[i]==mscore && factor[i]>maxfactor){
				max=i
               			mscore=score[i]
                		maxfactor=factor[i]
			}
		}
		result_c=cs[max]
		print(paste("***The best subspaces is",result_c))
	}else{
		max=1
		result_c=cs[max]
		print(paste("***The best subspaces is",result_c))
	}
	best_result=list(cluster=aucs[[max]]$cluster,temp=aucs[[max]]$temp,dist=aucs[[max]]$dist,best_c=result_c,best_k=k)
	rm(aucs)
	if(sample=="TRUE" || sample=="T"){
		best_result$lss=lss
	}
	return(best_result)
}
