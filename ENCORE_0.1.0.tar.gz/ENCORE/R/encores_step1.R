#' @describeIn subspace separation
#' @export
encore_gcluster=function(data,method="kmeans",start=50,end=0,nstart=10,den=512,thread=1){
        if(method=="kmeans"){
                if(end<=start){
			print(paste("running separation in kmeans mode with k=",start))
                        result1=dprofiles_kmeans_k(data,den=den,k=start,nstart=nstart)
                }else{
			print(paste("running separation in kmeans mode with k=",start,"to",end))
                        result1=dprofiles_kmeans(data,thread=thread,den=den,start=start,end=end,nstart=nstart)
                }
		if(is.na(result1)){
			stop("please change the subspace separation methods")
		}
        }else if(method=="both"){
		result1=dprofiles_gmm_k(data,den=den,k=start)
		if(is.null(result1)){
			result1=dprofiles_kmeans_k(data,den=den,k=start,nstart=nstart)
		}
	}else{
                if(end<=start){
			print(paste("running separation in GMM mode with k=",start))
                        result1=dprofiles_gmm_k(data,den=den,k=start)
                }else{
			print(paste("running separation in GMM mode with k=",start,"to",end))
                        result1=dprofiles_gmm(data,thread=thread,den=den,start=start,end=end)
                }
		if(is.null(result1)){
			stop("please change the subspace separation methods")
		}
        }
	result1=list(gcluster=result1$gcluster)
        return(result1)
}

#' subspace separation using GMM and kmeans
#'
#' Using an expression matrix as input, encore_step1 will scale data, separate features into different subspaces, and caculate and visualize distance matrices in subspaces.
#
#' @param data matrix; Data matrix (each row is an cell, each column is a gene).
#' @param method character; subspace separation method ("kmeans" or "gmm").
#' @param start integer; default: 50; If a end is set, and end>start, encore_step1 will choose the subspace numbers from start-end, and if end<=start, start subspaces will be got.
#' @param end integer; default: 0;
#' @param nstart integer; default: 10; How many random sets should be chosen in kmeans.
#' @param dens integer; default: 512; The number of equally spaced points at which the density is to be estimated.
#' @param thread integer; default: 1; Number of threads used.
#' @param scale character; default: TRUE. Scale the data by log2 or log10.
#' @param sample character; default: FALSE; When deal with big data of tens of thousands of cells , this parameter can be set to TRUE and encore will sample "10000/sample_size" cells firstly, and extend the cluster results to other cells by an supervised method
#' @param sample_size integer; default: 10000; cell numbers that sampled in sample process when sample=="TRUE"
#' @param minPts integer; default: 0; value of the minPts parameter in hdbscan cluster and in default set, 5, 10, 30 and 50 will be used for dataset with <250 cell, <5000 cells, <=10000 cells, >10000 cells.
#' @param perp integer; default: 0; Perplexity parameter in Rtsne function and in default, 15 and 30 will be used for dataset will <100 cells and >=100 cells.
#'
#' @examples
#' result1=encore_step1(data,thread=5)
#' result1=encore_step1(data,method="kmeans",start=10,end=50,thread=10)
#'
#' @return List with the following elements
#' \item{diss}{List, containing the distance matrices of subspaces}
#' \item{corr}{List, containing the correlation matrices of subspaces}
#' \item{ac}{Vector, contains the subspace index (ordered by the entropy of the subspace, low to high)}
#' \item{ts}{List, containing two-dimensional distribution of data in subspaces (transferred by t-sne)}
#' \item{k}{Integer, the infered priori number of cell groups}
#' \item{cs}{Vector, The mean cluster of each subspaces,returned by HDBSCAN}
#' \item{data}{data.frame, When sample="TRUE", this element will be return and contain the expression matrix of sampled cells}
#' \item{index}{Vector, When sample="TRUE", this element will be return and contain the index of the sampled cells and will be used in encore_large}
#' \item{gcluster}{Vector, When sample="TRUE", this element will be return and contain the feature classification results}
#'
#' @importFrom ggplot2 ggplot
#'
#' @export
encore_step1=function(data,method="kmeans",start=50,end=0,nstart=10,dens=512,thread=1,sample="FALSE",scale="TRUE",sample_size=10000,perp=0,minPts=0){
	if(sample=="TRUE" || sample=="T"){
		print(paste("Sample",sample_size,"cells from expression matrix"))
		dim1=dim(data)[1]
		index=sample(1:dim1,sample_size)
		data=data[index,]
	}
  if(scale=="TRUE"||scale=="T"){
    max_data=max(data)
    if(max_data>10000){
      data=log(data+1)/log(10)
    }else{
      data=log(data+1)/log(2)
    }
  }
	print("running subspace separation")
        result=encore_gcluster(data,method=method,start=start,end=end,den=dens,nstart=nstart,thread=thread)
        dim1=dim(data)[1]
        print(table(result$gcluster))
	if(minPts==0){
                if(dim1<=250){
                        minPts=5
                }else if(dim1<=5000){
                        minPts=10
                }else if(dim1<=10000){
                        minPts=30
                }else{
                        minPts=50
                }
        }
	if(perp==0){
                if(dim1<=100){
                        perp=15
                }else{
                        perp=30
                }
        }
	print("distance caculation in subspaces")
	      gcluster=result$gcluster
	      rm(result)
        result=mdistances(data=data,gcluster=gcluster,thread=thread,perp=perp,minPts=minPts)
        pdf(file="tsnes.pdf",width=8,height=4)
                result$tsnes
        dev.off()
	print("***The subspace ordered by entropies are:")
	print(result$ac)
	print(paste("***The suggest k for clustering in subspaces in spectral mode is",result$k))
	print("***The t-SNE plots in subspaces can be shown by type result$tsnes")
	if(sample=="TRUE" || sample=="T"){
		result$data=data
		result$index=index
		result$gcluster=gcluster
	}
	return(result)
        print("finish distance calculation")
}
