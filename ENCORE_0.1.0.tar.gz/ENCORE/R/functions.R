estk<- function(dataset) {
	p <- ncol(dataset)
	n <- nrow(dataset)
	x <- scale(dataset)
	rm(dataset)
    muTW <- (sqrt(n - 1) + sqrt(p))^2
    sigmaTW <- (sqrt(n - 1) + sqrt(p)) * (1/sqrt(n - 1) + 1/sqrt(p))^(1/3)
    sigmaHatNaive <- x%*%t(x)  # x left-multiplied by its transpose
    rm(x)
	bd <- 3.273 * sigmaTW + muTW
 	evals <- eigen(sigmaHatNaive, symmetric = TRUE, only.values = TRUE)$values
    k <- 0
    for (i in 1:length(evals)) {
        if (evals[i] > bd) {
            k <- k + 1
        }
    }
	return(k)
}


dprofiles_kmeans_k=function(data,den=512,k=k,nstart=10){
    #fs=apply(data,2,sum)
    #data=data[,fs!=0]
    #data=round(data,5)
	name=names(data)
	d=list()
	for(i in 1:dim(data)[2]){
        	a=density(as.numeric(data[,i]),n=den)
        	d[[i]]=a$y
    	}
	d=as.data.frame(d)
	names(d)=name
	d=as.data.frame(t(d))
	gcluster=kmeans(d,k,nstart=10)$cluster
        rm(d)
	#write.table(gcluster,file="gcluster.txt")
	result=list(gcluster=gcluster)
	return(result)
}


#' subspace separation based on kmeans
#'
#' @importFrom parallel makeCluster clusterExport stopCluster parLapply
dprofiles_kmeans=function(data,thread=1,den=512,start=16,end=25,nstart=10){
    #fs=apply(data,2,sum)
    #data=data[,fs!=0]
    #data=round(data,5)
	name=names(data)
	d=list()
	for(i in 1:dim(data)[2]){
        	a=density(as.numeric(data[,i]),n=den)
        	d[[i]]=a$y
	}
	d=as.data.frame(d)
    	names(d)=name
    	d=as.data.frame(t(d))
	cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
    	clusterExport(cl,"d",envir = environment())
    	mmclust=function(i){
        	a=kmeans(d,i,nstart=10)
        	return(a)
    	}
    	num2=start:end
    	c=parLapply(cl,num2,mmclust)
    	stopCluster(cl)
    	withins=c()
    	for(i in 1:length(num2)){
        	withins[i]=c[[i]]$tot.withinss
    	}
    	pdf(file="chose-k.pdf")
        	ks=data.frame(x=num2,y=withins)
    		plot(ks)
    	dev.off()
    	gcluster=kmeans(d,max(c[[order(withins)[1]]]$cluster),nstart=nstart)$cluster
    	#write.table(gcluster,file="gcluster.txt")
    	rm(d)
    	result=list(gcluster=gcluster)
    	return(result)
}

#' subspace separation based on GMM
#'
#' @importFrom mclust Mclust
dprofiles_gmm_k=function(data,k=4,den=512){
    	name=names(data)
    	d=list()
    	for(i in 1:dim(data)[2]){
        	a=density(as.numeric(data[,i]),n=den)
        	d[[i]]=a$y
    	}
    	d=as.data.frame(d)
    	names(d)=name
    	d=as.data.frame(t(d))
    	a=Mclust(d,k,modelNames = "VEV")
	rm(d)
#	save(a,file="gcluster.Rdata")
    	if(is.null(a)){
		return(NULL)
	}else{
		gcluster=a$classification
		rm(a)
		result=list(gcluster=gcluster)
       		return(result)
	}
}

#' subspace separation based on GMM with various k
#'
#' @importFrom mclust Mclust
#' @importFrom parallel makeCluster clusterExport stopCluster parLapply
dprofiles_gmm=function(data,start=2,end=10,den=512,thread=1){
#	fs=apply(data,2,sum)
#	data=data[,fs!=0]
#	data=round(data,5)
	name=names(data)
	#dx=list()
	d=list()
	for(i in 1:dim(data)[2]){
		a=density(as.numeric(data[,i]),n=den)
		d[[i]]=a$y
    	#	dx[[i]]=a$x
 	}
	d=as.data.frame(d)
	names(d)=name
	d=as.data.frame(t(d))
	cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
	clusterExport(cl,"d",envir = environment())
	mmclust=function(i){
        	a=Mclust(d,i)
        	return(a)
	}
	num2=start:end
	c=parLapply(cl,num2,mmclust)
	stopCluster(cl)
	rm(d)
	max=2
	maxBIC=c[[1]]$bic
	for(i in num2){
        	BIC=c[[(i-start+1)]]$bic
        	if(BIC>maxBIC){
                	max=i
                	maxBIC=BIC
        	}
	}
	stri=paste("The best cluster number is:",max)
	print(stri)
	#save(c[[max-start+1]],file="gclust.Rdata")
	gcluster=c[[(max-start+1)]]$classification
	rm(c)
	#write.table(gcluster,file="gcluster.txt")
	result=list(gcluster=gcluster)
	return(result)
}

#' Distance calculation in subspaces
#'
#' @importFrom parallel makeCluster clusterExport stopCluster parLapply
#' @importFrom Rtsne Rtsne
#' @importFrom fpc dbscan
#' @importFrom dbscan hdbscan
#' @importFrom ggplot2 ggplot
mdistances=function(data,gcluster,thread=1,perp=30,minPts=5,method="cor"){
	require(parallel)
  require(Rtsne)
  require(fpc)
  require(dbscan)
  require(ggplot2)
  data=as.data.frame(t(data))
	gcluster=as.data.frame(gcluster)
	names(gcluster)="x"
	if(thread>max(gcluster$x)){
		thread=max(gcluster$x)
	}
	c=1:max(gcluster$x)
	nd=merge(data,gcluster,by="row.names")
	rm(data)
	name=nd[,1]
	nd=nd[,2:dim(nd)[2]]
	row.names(nd)=name
	#nd$x=as.factor(nd$x)
	cl= makeCluster(getOption("cl.cores", thread),type="FORK")
	clusterExport(cl,"nd",envir = environment())
	clusterExport(cl,"perp",envir = environment())
	fun2=function(i){
		 b=nd[nd$x==i,]
		 b=b[,-dim(b)[2]]
       		 b=as.data.frame(b)
		 diss=matrix()
         	 cor=matrix()
		 gs=dim(b)[1]
		# if(gs<50){
		 #	diss=NA
		#	cor=NA
		#	used="TRUE"
		 #}else{
       		 	tb=as.matrix(b)
       		 	nb=t(t(tb+1)/(tb[1,]+1))
       		 	nnb=apply(nb,2,function(x) all(x==1))
			 rm(tb)
			 rm(nb)
       			 if(all(nnb==FALSE)){
              			used="FALSE"
               			cor=as.matrix(cor(b))
               			diss=1-cor
               			cor=cor-diag(rep(1,dim(b)[2]))
				if(dim(diss)[1]>=5000){
					theta=0.5
					iter=1000
				}else{
					theta=0
					iter=6000
				}
                		ts=Rtsne(diss,is_distance = TRUE,perplexity = perp,theta=theta,num_threads=thread,max_iter = iter)$Y
       		 	}else{
				diss=NA
				cor=NA
				ts=NA
               			used="TRUE"
        		}
		#}
       		result=list(dist=diss,cor=cor,used=used,ts=ts)
        	return(result)
	}
	fun3=function(i){
		b=nd[nd$x==i,]
                b=b[,-dim(b)[2]]
                b=as.data.frame(t(b))
        	temp=as.matrix(dist(b))
        	temp=(temp-min(temp))/(max(temp)-min(temp))
        	diss=temp
        	cor=1-temp-diag(rep(1,dim(b)[1]))
		used="FALSE"
		if(dim(diss)[1]>=5000){
		  theta=0.5
		  iter=1000
		}else{
		  theta=0
		  iter=6000
		}
		ts=Rtsne(diss,is_distance = TRUE,perplexity = perp,theta=theta,num_threads=thread,max_iter = iter)$Y
        	result=list(dist=diss,cor=cor,used=used,ts=ts)
		return(result)
	}
	if(method=="cor"){
		distance=parLapply(cl,c,fun2)
	}else{
		distance=parLapply(cl,c,fun3)
	}
		
	stopCluster(cl)
	names(distance)=c
	tused=c()
	for(i in c){
        	tused=c(tused,distance[[i]]$used)
	}
	names(tused)=c
	diss=list()
	corr=list()
	ts=list()
	for(i in c){
		if(tused[[i]]==FALSE){
        	diss[[i]]=distance[[i]]$dist
            corr[[i]]=distance[[i]]$cor
			ts[[i]]=distance[[i]]$ts
 		}else{
            diss[[i]]=NA
            corr[[i]]=NA
			ts[[i]]=NA
        }
	}
	temp=data.frame()
	tsnes=data.frame()
	for (i in as.numeric(as.character(c))){
		if(is.na(ts[[i]])){
		}else{
			temp=as.data.frame(ts[[i]][,1:2])
			temp_tsnes=data.frame(temp,group=rep(i,dim(temp)[1]))
			tsnes=rbind(tsnes,temp_tsnes)
		}
	}
	rm(temp)
	rm(temp_tsnes)
	if(dim(tsnes)[2]<1){
	  print(1)
	  result=list(diss=diss,corr=corr)
	}else{
	  print("********2*********")
	  names(tsnes)=c("tsne_1","tsne_2","group")
	  tsnes$group=as.factor(tsnes$group)
 	  p=ggplot(data=tsnes,aes(x=tsne_1,y=tsne_2,color=group,fill=group))+facet_wrap(.~group,ncol=4)+geom_point(size=0.5)+theme_bw()+theme(panel.border=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),axis.line=element_line(color="black"))
	#names(dd)=as.factor(c)
	  names(diss)=as.character(c)
	  names(corr)=as.character(c)
	  names(ts)=as.character(c)
	  cs=c()
	  cc=c()
	  for(i in c){
		  if(is.na(ts[[i]])){
		  	cs[i]=0
			  cc[i]=0
		  }else{
			  res <- hdbscan(ts[[i]], minPts =minPts)
			  if(is.na(res) || is.na(res$cluster) || is.na(res$cluster_score)){
				  cs[i]=0
				  cc[i]=0
			  }else if(sum(res$cluster_score)>100*length(res$cluster)){
				  cs[i]=0
				  cc[i]=0
			  }else{
				  cs[i]=mean(res$cluster_scores)
				  cc[i]=max(res$cluster)
			  }
		  }
	  }
	  rm(res)
	#names(dbs)=as.character(c)
	  ac=order(cs,decreasing = T)
	  ccc=(max(fpc::dbscan(ts[[ac[1]]],1.5)$cluster)+max(fpc::dbscan(ts[[ac[2]]],1.5)$cluster))/2
	#result=list(dd=dd,diss=diss,corr=corr,tused=tused,ts=ts,tsnes=p)
	  result=list(diss=diss,corr=corr,ac=ac,ts=ts,k=ccc,cs=cs,tsnes=p,gcluster=gcluster)
	}
	return(result)
}


#' Distance calculation in subspaces for big data
#'
#' @importFrom parallel makeCluster clusterExport stopCluster parLapply
mdistances_bg=function(data,gcluster,c,thread=5,perp=30){
	data=as.data.frame(t(data))
	gcluster=as.data.frame(gcluster)
	names(gcluster)="x"
	if(thread>max(gcluster$x)){
		thread=max(gcluster$x)
	}
	nd=merge(data,gcluster,by="row.names")
	rm(data)
	rm(gcluster)
	name=nd[,1]
	nd=nd[,2:dim(nd)[2]]
	row.names(nd)=name
	nd$x=as.factor(nd$x)
	c=as.numeric(as.character(c))
	nd=nd[nd$x %in% c,]
	fun1=function(i){
       	b=nd[nd$x==i,]
        b=b[,-dim(b)[2]]
       	b=as.data.frame(b)
       	tb=as.matrix(b)
       	nb=t(t(tb+1)/(tb[1,]+1))
       	nnb=apply(nb,2,function(x) all(x==1))
       	rm(tb)
       	rm(nb)
       	diss=matrix()
       	cor=matrix()
       	if(all(nnb==FALSE)){
            used="FALSE"
            cor=as.matrix(cor(b))
            diss=1-cor
            cor=cor-diag(rep(1,dim(b)[2]))
       	}else{
             used="TRUE"
        }
       	result=list(dist=diss,cor=cor,used=used)
       	rm(diss)
       	rm(cor)
        return(result)
	}
	fun2=function(b){
        tb=as.matrix(b)
        nb=t(t(tb+1)/(tb[1,]+1))
        nnb=apply(nb,2,function(x) all(x==1))
		rm(tb)
		rm(nb)
        diss=matrix()
        cor=matrix()
        if(all(nnb==FALSE)){
        	used="FALSE"
            cor=as.matrix(cor(b))
            diss=1-cor
            cor=cor-diag(rep(1,dim(b)[2]))
        }else{
            used="TRUE"
        }
        result=list(dist=diss,cor=cor,used=used)
        rm(diss)
        rm(cor)
        return(result)
    }
	if(thread>1){
		cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
        clusterExport(cl,"nd",envir = environment())
		distance=parLapply(cl,as.character(c),fun1)
		stopCluster(cl)
	}else{
		distance=list()
		nu=1
		for(i in as.character(c)){
			b=nd[nd$x==i,]
			b=b[,-dim(b)[2]]
            b=as.data.frame(b)
			distance[[nu]]=fun2(b)
			nu=nu+1
			rm(b)
		}
	}
	names(distance)=as.character(c)
	tused=c()
	for(i in as.character(c)){
        tused=c(tused,distance[[i]]$used)
	}
	names(tused)=as.character(c)
	diss=list()
	corr=list()
	for(i in as.character(c)){
		if(tused[[i]]==FALSE){
        	diss[[i]]=distance[[i]]$dist
            corr[[i]]=distance[[i]]$cor
 		}else{
            diss[[i]]=NA
            corr[[i]]=NA
        }
	}
	rm(distance)
	names(diss)=as.factor(c)
	names(corr)=as.factor(c)
	#result=list(dd=dd,diss=diss,corr=corr,tused=tused,ts=ts,tsnes=p)
	result=list(diss=diss,corr=corr,used=tused)
	rm(diss)
	rm(corr)
	return(result)
}



#' eigens of corrs 1
#'
LS=function(i){
	if(is.na(i)){
		ll="wrong";
	}else{
		corr[[i]][corr[[i]]<0]=0
		W=as.matrix(corr[[i]])
		corr[[i]]="NA"
		s=colSums(W)
		s=s^(-1/2)
		D=diag(s)
		rm(s)
		L=diag(rep(1,dim(W)[1]))-D%*%W%*%D
		rm(W)
		rm(D)
		if(sum(is.na(L)>0)){
			ll="wrong"
		}else{
			ll=eigen(L)
    	}
    	print(i)
	}
	rm(L)
    return(ll)
}


#' eigens of corrs 2
#'
LS2=function(W){
	W[W<0]=0
    s=colSums(W)
    s=s^(-1/2)
    D=diag(s)
    rm(s)
    L=diag(rep(1,dim(W)[1]))-D%*%W%*%D
    rm(W)
    rm(D)
    if(sum(is.na(L)>0)){
    	ll="wrong"
    }else{
        ll=eigen(L)
    }
    rm(L)
    return(ll)
}


#' spectral cluster
#'
specc=function(i){
	if(is.na(i)){
		ll="wrong";
    }else{
		corr[[i]][corr[[i]]<0]=0
        W=as.matrix(corr[[i]])
        corr[[i]]=NA
        s=colSums(W)
        s=s^(-1/2)
        D=diag(s)
        rm(s)
        L=diag(rep(1,dim(W)[1]))-D%*%W%*%D
		rm(W)
		rm(D)
        if(sum(is.na(L)>0)){
            ll="wrong"
        }else{
            ll=eigen(L)
        }
        rm(L)
		U=ll$vectors[,order(ll$values)[1:k]]
		rm(ll)
        s2=(rowSums(U^2))^(1/2)
        for (i in 1:dim(U)[1]){
        	for (j in 1:dim(U)[2]){
            	U[i,j]=U[i,j]/s2[i]
            }
        }
        return(U)
	}
}


#' clustering in subspace with spectral cluster
#'
part_cluster1=function(z){
  	U=lss[[z]]$vectors[,order(lss[[z]]$values)[1:k]]
    	s2=(apply(U^2,1,sum))^(1/2)
    	for (i in 1:dim(U)[1]){
        	for (j in 1:dim(U)[2]){
          		U[i,j]=U[i,j]/s2[i]
        	}
    	}
    	rm(s2)
        print("running spectral clustering")
	pcluster = kmeans(U, k,nstart=25)$cluster
        return(pcluster)
}


#' clustering in subspace with hdbscan
#'
#' @importFrom dbscan hdbscan
part_cluster2=function(z){
	pcluster=hdbscan(ts[[z]],minPts=minPts)$cluster
	return(pcluster)
}


#' learn distance
#'
learn_distance=function(c,pclusters,diss,corr){
	length=length(pclusters[[1]])
	w=matrix(0,length,length)
    	dis=matrix(0,length,length)
	cor=matrix(0,length,length)
    	for(i in as.character(c)){
       		cluster=pclusters[[i]]
       		pclusters[[i]]=NA
       		j1=1
		while (j1 <length){
			j2=j1+1
			while(j2 <= length){
				if(cluster[j1]==cluster[j2] && cluster[j1]!=0){
					w[j1,j2]=w[j1,j2]+1
					w[j2,j1]=w[j2,j1]+1
				}
				j2=j2+1
			}
			j1=j1+1
		}
		dis=dis+diss[[as.numeric(as.character(i))]]
		cor=cor+corr[[as.numeric(as.character(i))]]
	}
	cor=as.matrix(cor)*((1/(2*length(c)))*w+1)
   	dis=as.matrix(dis)*(1/((1/(2*length(c)))*w+1))
    	result=list(dis=dis,cor=cor)
    	rm(cor)
    	rm(dis)
    	rm(w)
    	return(result)
}


#' consensus clustering
#'
#' @importFrom Rtsne Rtsne
#' @importFrom dbscan hdbscan
s_cluster=function(dis,perp=30,minPts=10,thread=1){
	if(dim(dis)[1]>=5000){
		theta=0.5
		iter=1000
	}else{
		theta=0
		iter=2000
	}
	tsne_obj=Rtsne(dis, is_distance = TRUE,perplexity=perp,theta=theta, max_iter = iter,num_threads=thread)
	temp=as.data.frame(tsne_obj$Y)
	rm(tsne_obj)
	res=hdbscan(temp,minPts=minPts)
	temp$clusters=as.factor(res$cluster)
	rm(res)
	names(temp)=c("tsne_1","tsne_2","clusters")
	result=list(temp=temp)
	return(result)
}


#' IAUC score calculation
#'
#' @importFrom parallel makeCluster clusterExport stopCluster parLapply
#' @importFrom pROC roc
IAUC=function(data,index,dist,c=c,pc=0.05,perp=30,minPts=10,nm=5,thread=1){
	result3=s_cluster(dist[[1]],perp=perp,minPts=minPts,thread=thread)
	cluster=result3$temp$clusters
	dist=dist[[1]]
    	my_test<-function(i){
        	f=data[i,]
        	tresult=cor.test(as.double(f),ncluster)
        	p=tresult$p.value
        	t=as.numeric(as.character(tresult$estimate))
        	if(is.na(p)){
        	}else if(p<pc && t>0){
        		t="up"
            		comp=data.frame(as.double(f),ncluster)
            		roc1=roc(comp[,2],comp[,1])
            		auc1=as.numeric(roc1$auc)
            		result=data.frame(p,auc1,name[i],t)
            		row.names(result)=name[i]
            		return(result)
        	}else if(p<pc && t<0){
           		t="down"
            		comp=data.frame(as.double(f),ncluster)
            		roc1=roc(comp[,2],comp[,1])
            		auc1=as.numeric(roc1$auc)
            		result=data.frame(p,auc1,name[i],t)
            		row.names(result)=name[i]
            		return(result)
        	}else{
		}
	}
    	acluster=cluster
   	cluster=cluster[index]
	clu=levels(cluster)
    	gmarkers=c()
    	aaucs=c()
	cluu=max(as.numeric(clu))
	cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
        name=row.names(data)
        clusterExport(cl,"name",envir = environment())
        clusterExport(cl,"pc",envir = environment())
        clusterExport(cl,"data",envir = environment())
    	for(i in 1:cluu){
    		ncluster=cluster
        	ncluster=as.numeric(as.character(ncluster))
        	nncluster=ncluster
        	ncluster[nncluster!=as.numeric(i)]=0
        	ncluster[nncluster==as.numeric(i)]=1
        	rm(nncluster)
        	clusterExport(cl,"ncluster",envir = environment())
        	num=dim(data)[1]
        	nums=1:num
        	marker=parLapply(cl,nums,my_test)
        	markers=do.call(rbind,marker)
        	if(is.null(markers)){
        		aaucs=aaucs
        	}else{
        		markers=as.data.frame(markers)
        		markers$cluster=rep(i,dim(markers)[1])
        		markers$p=p.adjust(markers$p,method="holm",n=num*length(clu))
        		markers=markers[markers$p<pc,]
        		z=order(markers$auc1,decreasing = TRUE)
        		markers=markers[z,]
        		gmarkers=rbind(gmarkers,markers)
        		if(length(markers$auc1)>=nm){
        			aaucs=c(aaucs,mean(markers[1:nm,]$auc1))
        		}else{
				aaucs=c(aaucs,sum(markers$auc1)/nm)
        		}
        	}
		rm(ncluster)
	}
	stopCluster(cl)
#	IAUC=median(aaucs)
    	IAUC=(median(aaucs)+mean(aaucs))/2
	result=list(IAUC=IAUC,gene_markers=gmarkers,cluster=acluster,temp=result3$temp,dist=dist)
	rm(gmarkers)
	rm(result3)
    	return(result)
}

