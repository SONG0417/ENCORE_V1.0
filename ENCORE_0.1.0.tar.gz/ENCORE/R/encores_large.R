#' extension to big data by an supervised methods
#'
#' Using the expression matrix and the results from encore_step1 and encore_step2 as input, encore_big will extend the cluster results of sampled cells to rest cells using a supervised method.
#
#' @param data matrix; Data matrix (each row is an cell, each column is a gene).
#' @param result1 List; default: NA. Must be set to the result from encore_step2.
#' @param result List; default: NA. Must be set to the result from encore_step1.
#' @param scale character; default: TRUE. Scale the data by log2 or log10.
#' @param thread integer; default: 1; Number of threads used
#' @param perp integer; default: 0; Perplexity parameter in Rtsne function and in default, 15 and 30 will be used for dataset will <100 cells and >=100 cells.
#'
#' @examples
#' result1=encore_step1(data,dens=2000,thread=2,sample="TRUE")
#' result2=encore_step2(result=result1,k=c(38,39,40,41,42),sample="TRUE",thread=4)
#' result=encore_big(data=data,result=result2,result1=result1,thread=2)
#'
#' @return List with the following elements
#' \item{temp}{data.frame, Two-dimensional cell distribution obtained by tsne transformation, and the final cluster results}
#'
#' @import ggplot2
#' @import reshape2
#' @import parallel
#' @import dbscan
#' @import e1071
#'
#' @export
encore_big=function(data=NA,result=NA,result1=NA,scale="TRUE",thread=1,perp=0){
	if(is.na(data) || is.na(result1) || is.na(result) ){
                print("Please check parameters, Missing some parameters")
	}
  if(scale=="TRUE"||scale=="T"){
    max_data=max(data)
    if(max_data>10000){
      data=log(data+1)/log(10)
    }else{
      data=log(data+1)/log(2)
    }
  }
  dim1=dim(data)[1]
	if(perp==0){
                if(dim1<=100){
                        perp=15
                }else{
                        perp=30
                }
  }
	scluster=as.numeric(as.character(result$cluster))
	c=result$best_c[[1]]
	k=result$best_k[[1]]
	lss=result$lss
	rm(result)
	index=result1$index
	gcluster=result1$gcluster
	rm(result1)
	sample_size=length(index)
#####调整分类结果
	cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
	clusterExport(cl,"k",envir = environment())
	clusterExport(cl,"lss",envir = environment())
	pclu2=function(z){
		U=lss[[z]]$vector[,order(lss[[z]]$values)[1:k]]
        	s2=(apply(U^2,1,sum))^(1/2)
        	for (i in 1:dim(U)[1]){
        		for (j in 1:dim(U)[2]){
				U[i,j]=U[i,j]/s2[i]
                	}
        	}
    		return(U)
	}
	Us=parLapply(cl,as.character(c),pclu2)
	stopCluster(cl)
	rm(lss)
	USA=Us[[1]]
	for(i in 2:length(c)){
        	USA=cbind(USA,Us[[i]])
	}
	rm(Us)
	USA=as.data.frame(USA)
	USAs=paste("USA",1:dim(USA)[2],sep=".")
	names(USA)=USAs
	train_data=USA
	train_data$cluster=as.factor(scluster)
	index2=sample(1:length(index),0.8*length(index))
	train=train_data[index2,]
	test=train_data[-index2,]
	print("Run tune svm")
	tuned<-tune.svm(cluster ~ .,data = train,gamma=10^(-6:0),cost=10^(1:2),kernel="sigmoid")
	#save(tuned,file="tuned.Rdata")
	#load("tuned.Rdata")
	svm.model <- svm(cluster ~ ., data = train, cost = tuned$best.parameters[[2]], gamma =tuned$best.parameters[[1]],type="C-classification",kernel="sigmoid")
	print("The error of SVM:")
	print(mean(test$cluster!=predict(svm.model,test)))
	scluster=predict(svm.model,USA)
	rm(USA)
	rm(train_data)
	rm(train)
	rm(test)
	rm(svm.model)
	print("Calculate distance on whole matrix")
	result=mdistances_bg(data,gcluster,c=c,thread=1)
	diss=result$diss
	rm(data)
	#load("aresult.Rdata")
	print("Finish distance calculation")
	all_corr=result$corr
	rm(result)
	rm(gcluster)
	all_cluster=rep("NA",dim1)
	nu=0
	all_index=1:dim1
	all_index=all_index[-index]
	end=0
	dim2=length(all_index)
	step=round(sample_size*0.4,0)
	while(end<dim2){
		print(paste("complete no.",nu))
		if((nu+1)*step<=dim2){
			cur=all_index[(nu*step+1):((nu+1)*step)]
			end=(nu+1)*step
		}else{
			cur=all_index[(nu*step+1):dim2]
			end=dim2
		}
		nu=nu+1
		index2=sample(sample_size,round(sample_size*0.8,0))
		cur=c(index[index2],cur)
		corr=list()
		for(i in 1:length(c)){
			corr[[i]]=all_corr[[i]][cur,cur]
		}
		print(paste("Deal with",length(cur),"cells"))
		names(corr)=as.character(c)
		cl <- makeCluster(getOption("cl.cores", thread),type="FORK")
		clusterExport(cl,"corr",envir = environment())
		clusterExport(cl,"k",envir = environment())
		Us=parLapply(cl,as.character(c),specc)
		stopCluster(cl)
		names(Us)=as.character(c)
		rm(corr)
		#基于LS计算USA
		USA=Us[[1]]
		for(i in 2:length(c)){
			USA=cbind(USA,Us[[i]])
		}
		rm(Us)
		USAs=paste("USA",1:dim(USA)[2],sep=".")
		USA=as.data.frame(USA)
		names(USA)=USAs
		print("Got features in new dimension")
		######svm train
		perp=30
		train_data=USA[1:round(sample_size*0.8,0),]
		train_data$cluster=as.factor(scluster[index2])
		svm.model <- svm(cluster ~ ., data = train_data, cost = tuned$best.parameters[[2]], gamma =tuned$best.parameters[[1]],type="C-classification",kernel="sigmoid")
		cluster=predict(svm.model,USA)
		all_cluster[cur]=as.factor(cluster)
	}
	print("Finish cell clustering and the cluster results are save in cluster.txt")
	all_cluster[index]=as.factor(scluster)
	write.table(all_cluster,file="cluster.txt")
	cluster=all_cluster
	length=dim1
	dis=matrix(0,length,length)
	for(i in as.character(c)){
       		dis=dis+diss[[i]]
	}
	rm(diss)
	j1=1
	rm(all_cluster)
	while (j1 <length){
		j2=j1+1
		while(j2 <= length){
			if(cluster[j1]==cluster[j2]){
				dis[j1,j2]=dis[j1,j2]/2
				dis[j2,j1]=dis[j2,j1]/2
			}
			j2=j2+1
		}
		j1=j1+1
	}
	library(Rtsne)
	print("Start Rtsne")
	tsne_obj=Rtsne(dis, is_distance = TRUE,perplexity=perp,num_threads=5)
	temp=as.data.frame(tsne_obj$Y)
	rm(tsne_obj)
	temp$cluster=cluster
	names(temp)=c("tsne_1","tsne_2","clusters")
	return(temp)
}
